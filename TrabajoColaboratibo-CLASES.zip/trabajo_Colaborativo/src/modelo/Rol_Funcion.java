package modelo;

public class Rol_Funcion {

}
