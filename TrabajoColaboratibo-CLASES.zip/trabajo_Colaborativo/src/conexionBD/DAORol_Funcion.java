package conexionBD;

import java.sql.*;
import modelo.Funcionalidad;
import modelo.Rol;

public class DAORol_Funcion {
	
	private static final String INSERT_ROL_FUNCION = "INSERT INTO ROL_FUNCION (ID_FUNCION, ID_ROL) values (?, ?)";
	
	private static final String UPDATE_ROL_FUNCION = "UPDATE ROL_FUNCION SET ID_FUNCION=?, ID_ROL=?";
	
	private static final String DELETE_ROL_FUNCION = "DELETE FROM ROL_FUNCION WHERE ID_ROL=? AND ID_FUNCION=?";
	
	
	
	public static boolean insert(Rol r, Funcionalidad f) {
		
		try {
			PreparedStatement statement = ConexionBD.getConnection().prepareStatement(INSERT_ROL_FUNCION);
			
			statement.setLong(1, f.getIdFuncionalidad());
			statement.setLong(2, r.getIdRol());
			
			int Retorno = statement.executeUpdate();
			
			Rol rol = DAORol.findRol(r.getNombreRol());
			Funcionalidad funcion = DAOFuncionalidad.findFuncionalidad(f.getNombreFuncion());
			
			rol.getFunciones().add(funcion);
			funcion.getRoles().add(rol);
			
			return Retorno > 0;
			
		} catch(SQLIntegrityConstraintViolationException e) {
			return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	public static boolean edit(Rol r, Funcionalidad f) {
		
		try {
			PreparedStatement statement = ConexionBD.getConnection().prepareStatement(UPDATE_ROL_FUNCION);
			
			statement.setLong(1, f.getIdFuncionalidad());
			statement.setLong(2, r.getIdRol());
			
		
			if(!(r.getFunciones().contains(f))) {
				r.getFunciones().add(f);
			}
			
			if(!(f.getRoles().contains(r))) {
				f.getRoles().add(r);
			}
			
			
			int Retorno = statement.executeUpdate();
			
			return Retorno > 0;
		} catch(SQLIntegrityConstraintViolationException e) {
			return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}	
	}
	
	public static boolean delete(Rol r, Funcionalidad f) {
		PreparedStatement statement;
		
		try{ 
			statement = ConexionBD.getConnection().prepareStatement(DELETE_ROL_FUNCION);
			
			statement.setLong(1, r.getIdRol());
			statement.setLong(2, f.getIdFuncionalidad());
			
			r.getFunciones().remove(f);
			f.getRoles().remove(r);
			
			int Retorno = statement.executeUpdate();
			
			return Retorno > 0;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}	
	}

}
