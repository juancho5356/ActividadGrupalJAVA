package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.SwingConstants;

import conexionBD.DAOPersona;
import modelo.Persona;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.SystemColor;

public class LogIn {

	private JFrame frmLogin;
	private JPasswordField password;
	private JTextField textCorreo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogIn window = new LogIn();
					window.frmLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LogIn() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLogin = new JFrame();
		frmLogin.setTitle("LogIn");
		frmLogin.getContentPane().setBackground(new Color(220, 220, 220));
		frmLogin.getContentPane().setForeground(Color.WHITE);
		frmLogin.setBounds(100, 100, 781, 388);
		frmLogin.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmLogin.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("LogIn");
		lblNewLabel_1.setForeground(new Color(105, 105, 105));
		lblNewLabel_1.setFont(new Font("Baskerville Old Face", Font.PLAIN, 66));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBackground(Color.WHITE);
		lblNewLabel_1.setBounds(10, 10, 747, 71);
		frmLogin.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Correo electr�nico");
		lblNewLabel.setForeground(new Color(105, 105, 105));
		lblNewLabel.setFont(new Font("Baskerville Old Face", Font.PLAIN, 27));
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setBounds(27, 123, 272, 43);
		frmLogin.getContentPane().add(lblNewLabel);
		
		JLabel lblContrasea = new JLabel("Contrase�a");
		lblContrasea.setForeground(new Color(105, 105, 105));
		lblContrasea.setHorizontalAlignment(SwingConstants.LEFT);
		lblContrasea.setFont(new Font("Baskerville Old Face", Font.PLAIN, 27));
		lblContrasea.setBounds(25, 192, 190, 43);
		frmLogin.getContentPane().add(lblContrasea);
		
		password = new JPasswordField();
		password.setFont(new Font("Tahoma", Font.PLAIN, 20));
		password.setBounds(309, 194, 448, 37);
		frmLogin.getContentPane().add(password);
		
		textCorreo = new JTextField();
		textCorreo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textCorreo.setBounds(309, 125, 448, 37);
		frmLogin.getContentPane().add(textCorreo);
		textCorreo.setColumns(10);
		
		JButton btnAdministrador = new JButton("Administrador");
		btnAdministrador.setBackground(SystemColor.control);
		btnAdministrador.setFont(new Font("Baskerville Old Face", Font.PLAIN, 20));
		btnAdministrador.setBounds(269, 290, 228, 37);
		frmLogin.getContentPane().add(btnAdministrador);
		
		JButton btnJefe = new JButton("Jefe de seccion");
		btnJefe.setBackground(SystemColor.control);
		btnJefe.setFont(new Font("Baskerville Old Face", Font.PLAIN, 20));
		btnJefe.setBounds(10, 290, 228, 37);
		frmLogin.getContentPane().add(btnJefe);
		
		JButton btnOperador = new JButton("Operador de seccion");
		btnOperador.setBackground(SystemColor.control);
		btnOperador.setFont(new Font("Baskerville Old Face", Font.PLAIN, 20));
		btnOperador.setBounds(529, 290, 228, 37);
		frmLogin.getContentPane().add(btnOperador);
		
		
		
		btnAdministrador.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				if(!(textCorreo.getText().isEmpty() || password.getText().isEmpty())) {
					LinkedList<Persona> administradores = new LinkedList<>();
					administradores = DAOPersona.findAdmin();
					
					LinkedList<String> correos = new LinkedList<>();
					for(Persona p: administradores) {
						correos.add(p.getMail());
					}
					
					LinkedList<String> claves = new LinkedList<>();
					for(Persona p: administradores) {
						claves.add(p.getClave());
					}
					
					if((correos.contains(textCorreo.getText()) && (claves.contains(password.getText())))) {
						System.out.println("Usuario aceptado");
						MenuAdmin.main(null);
						textCorreo.setText("");
						password.setText("");
					}
					else {
						JOptionPane.showMessageDialog(null, "Credenciales incorrectas");
					}
				}else {
					JOptionPane.showMessageDialog(null, "Por favor ingrese ambos campos");

				}
				
			}
		});
				
		
		btnJefe.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				if(!(textCorreo.getText().isEmpty() || password.getText().isEmpty())) {
					LinkedList<Persona> jefes = new LinkedList<>();
					jefes = DAOPersona.findJefe();
					
					LinkedList<String> correosJ = new LinkedList<>();
					for(Persona s: jefes) {
						correosJ.add(s.getMail());
					}
					
					LinkedList<String> clavesJ = new LinkedList<>();
					for(Persona t: jefes) {
						clavesJ.add(t.getClave());
					}
					
					if((correosJ.contains(textCorreo.getText()) && (clavesJ.contains(password.getText())))) {
						System.out.println("Usuario aceptado");
						MenuJefe.main(null);
						textCorreo.setText("");
						password.setText("");
					}
					else {
						JOptionPane.showMessageDialog(null, "Credenciales incorrectas");
					}
				}else {
					JOptionPane.showMessageDialog(null, "Por favor ingrese ambos campos");

				}
				
			}
		});
				
				
		btnOperador.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				if(!(textCorreo.getText().isEmpty() || password.getText().isEmpty())) {
					LinkedList<Persona> operadores = new LinkedList<>();
					operadores = DAOPersona.findOperador();
					
					LinkedList<String> correosO = new LinkedList<>();
					for(Persona x: operadores) {
						correosO.add(x.getMail());
					}
					
					LinkedList<String> clavesO = new LinkedList<>();
					for(Persona y: operadores) {
						clavesO.add(y.getClave());
					}
					
					if((correosO.contains(textCorreo.getText()) && (clavesO.contains(password.getText())))) {
						System.out.println("Usuario aceptado");
						MenuOperador.main(null);
						textCorreo.setText("");
						password.setText("");
					}
					else {
						JOptionPane.showMessageDialog(null, "Credenciales incorrectas");
					}
				}else {
					JOptionPane.showMessageDialog(null, "Por favor ingrese ambos campos");

				}
				
			}
		});
	}
}