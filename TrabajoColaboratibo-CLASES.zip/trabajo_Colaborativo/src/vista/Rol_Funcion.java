package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.ComponentOrientation;
import java.awt.Font;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import conexionBD.DAOFuncionalidad;
import conexionBD.DAORol;
import conexionBD.DAORol_Funcion;
import modelo.Funcionalidad;
import modelo.Rol;

public class Rol_Funcion {

	private JFrame frame;
	private JScrollPane scrollPane;
	private JTable table;
	private JLabel lblRol_Funcion;
	private JTabbedPane tabbedPane;
	private JPanel panel;
	private JPanel panel_1;
	private JLabel lblRol;
	private JComboBox <Object> comboBoxRol;
	private JLabel lblFuncion;
	private JComboBox<Object> comboBoxFuncion;
	private JButton btnIngresar;
	private JLabel lblIngreso;
	private JLabel lblEliminar;
	private JLabel lblRol_1;
	private JComboBox<Object> comboRol_2;
	private JComboBox<Object> comboFuncionalidad_3;
	private JLabel lblFuncion_1;
	private JButton btnConfirmar;
	private JTextField textIDR;
	private JButton btnEliminar;
	private JPanel panel_2;
	private JLabel lblActualizar;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JTextField textIDF;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rol_Funcion window = new Rol_Funcion();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Rol_Funcion() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(72, 209, 204));
		frame.setBounds(100, 100, 1206, 556);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 62, 707, 447);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		lblRol_Funcion = new JLabel("Rol_Funcion");
		lblRol_Funcion.setFont(new Font("Bookman Old Style", Font.BOLD, 40));
		lblRol_Funcion.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		lblRol_Funcion.setBounds(10, 10, 496, 42);
		frame.getContentPane().add(lblRol_Funcion);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(727, 62, 455, 202);
		frame.getContentPane().add(tabbedPane);
		
		panel = new JPanel();
		panel.setBackground(SystemColor.control);
		tabbedPane.addTab("Agregar Rol_Funcion", null, panel, null);
		panel.setLayout(null);
		
		lblRol = new JLabel("Elegir Rol");
		lblRol.setBounds(10, 45, 115, 21);
		panel.add(lblRol);
		
		comboBoxRol = new JComboBox<Object>();
		comboBoxRol.setBounds(147, 45, 293, 21);
		panel.add(comboBoxRol);
		LinkedList<Rol> allRoles = DAORol.findAll();
		
		for (int i=0;i<allRoles.size();i++){
			String rol = allRoles.get(i).getNombreRol();
			comboBoxRol.addItem(rol);
		} 
		
		lblFuncion = new JLabel("Elegir Funcionalidad");
		lblFuncion.setBounds(10, 80, 127, 21);
		panel.add(lblFuncion);
		
		comboBoxFuncion = new JComboBox<Object>();
		comboBoxFuncion.setBounds(147, 80, 293, 21);
		panel.add(comboBoxFuncion);
		LinkedList<Funcionalidad> allFuncion = DAOFuncionalidad.findAll();
		
		for (int i=0;i<allFuncion.size();i++){
			String funcion = allFuncion.get(i).getNombreFuncion();
			comboBoxFuncion.addItem(funcion);
		} 
		
		btnIngresar = new JButton("Ingresar");
		btnIngresar.setBackground(SystemColor.inactiveCaptionBorder);
		btnIngresar.setBounds(10, 144, 111, 21);
		panel.add(btnIngresar);
		btnIngresar.addActionListener(new ActionListener () {
			public void actionPerformed (ActionEvent e) {
				String r = (String) comboBoxRol.getSelectedItem();
				String f = (String) comboBoxFuncion.getSelectedItem();
				try {	
					Rol rol = DAORol.findRol(r);
					Funcionalidad funcion = DAOFuncionalidad.findFuncionalidad(f);
					
					if (DAORol_Funcion.insert(rol, funcion)) {
						JOptionPane.showMessageDialog(null, "�xito");

					}else {
						JOptionPane.showMessageDialog(null, "No es posible a�adir este registro");
					}
					
				}catch(RuntimeException ex) {
					JOptionPane.showMessageDialog(null, "No es posible a�adir este registro");
				}
			
				lista();
				
				
			}
		});
		
		
		lblIngreso = new JLabel("Ingreso");
		lblIngreso.setBounds(10, 10, 111, 25);
		panel.add(lblIngreso);
		lblIngreso.setFont(new Font("Bookman Old Style", Font.BOLD, 20));
		lblIngreso.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		
		panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.control);
		tabbedPane.addTab("Modificar", null, panel_1, null);
		panel_1.setLayout(null);
		
		lblRol_1 = new JLabel("Elegir Rol");
		lblRol_1.setBounds(10, 45, 115, 21);
		panel_1.add(lblRol_1);
		
		comboRol_2 = new JComboBox<Object>();
		comboRol_2.setBounds(147, 45, 293, 21);
		panel_1.add(comboRol_2);
		
		for (int i=0;i<allRoles.size();i++){
			String rol = allRoles.get(i).getNombreRol();
			comboRol_2.addItem(rol);
		} 
		
		comboFuncionalidad_3 = new JComboBox<Object>();
		comboFuncionalidad_3.setBounds(147, 80, 293, 21);
		panel_1.add(comboFuncionalidad_3);
		
		for (int i=0;i<allFuncion.size();i++){
			String funcion = allFuncion.get(i).getNombreFuncion();
			comboFuncionalidad_3.addItem(funcion);
		} 
		
		lblFuncion_1 = new JLabel("Elegir Funcionalidad");
		lblFuncion_1.setBounds(10, 80, 127, 21);
		panel_1.add(lblFuncion_1);
		
		btnConfirmar = new JButton("Confirmar");
		btnConfirmar.setBackground(SystemColor.inactiveCaptionBorder);
		btnConfirmar.setBounds(10, 144, 111, 21);
		panel_1.add(btnConfirmar);
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						String r = (String) comboBoxRol.getSelectedItem();
						String f = (String) comboBoxFuncion.getSelectedItem();
					try {
						
						Rol rol = DAORol.findRol(r);
						Funcionalidad fun = DAOFuncionalidad.findFuncionalidad(f);
						
						try {	
							if(DAORol_Funcion.edit(rol, fun)) {
								JOptionPane.showMessageDialog(null, "�xito");
								
							}else {
								JOptionPane.showMessageDialog(null, "No es posible modificar este registro");
							}
							
						}catch (Exception ex) {
							JOptionPane.showMessageDialog(null, "No es posible modificar este registro");
						}
					}catch(Exception ex) {
						JOptionPane.showMessageDialog(null, "El registro que acaba de ingresar, no se encuentra en el sistema");
					}
					lista();	
			}
		});
		
		lblActualizar = new JLabel("Actualizaci\u00F3n");
		lblActualizar.setFont(new Font("Bookman Old Style", Font.BOLD, 20));
		lblActualizar.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		lblActualizar.setBounds(10, 10, 207, 25);
		panel_1.add(lblActualizar);
		
		panel_2 = new JPanel();
		panel_2.setBounds(727, 409, 455, 100);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		lblEliminar = new JLabel("Eliminar funcionalidad de un Rol");
		lblEliminar.setBounds(10, 14, 353, 13);
		panel_2.add(lblEliminar);
		
		textIDR = new JTextField();
		textIDR.setBounds(188, 37, 49, 21);
		panel_2.add(textIDR);
		textIDR.setColumns(10);
		textIDR.setBackground(Color.WHITE);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.setBackground(SystemColor.inactiveCaptionBorder);
		btnEliminar.setBounds(360, 54, 85, 21);
		panel_2.add(btnEliminar);
		btnEliminar.addActionListener(new ActionListener () {
			public void actionPerformed(ActionEvent e) {
				if(!(textIDR.getText().isEmpty() || textIDF.getText().isEmpty())) {
					try {
						int idR = Integer.parseInt(textIDR.getText());
						int idF = Integer.parseInt(textIDF.getText());
						
						Rol r = DAORol.findRolID(idR);
						Funcionalidad f = DAOFuncionalidad.findFuncionalidadID(idF);
						
						if(DAORol_Funcion.delete(r, f)) {
							JOptionPane.showMessageDialog(null, "Exito");
							
							textIDR.setText("");
							textIDF.setText("");
						}
						else {
							JOptionPane.showMessageDialog(null, "No es posible eliminar el registro");
						}
					}catch(Exception ex) {
						JOptionPane.showMessageDialog(null, "No existe el registro");
					}
					
				}
				else {
					JOptionPane.showMessageDialog(null, "Por favor ingrese ambos campos");
				}
			}
		});
		
		lblNewLabel = new JLabel("Ingrese ID Rol");
		lblNewLabel.setBounds(10, 37, 112, 21);
		panel_2.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Ingrese ID Funcionalidad");
		lblNewLabel_1.setBounds(10, 71, 164, 21);
		panel_2.add(lblNewLabel_1);
		
		textIDF = new JTextField();
		textIDF.setBounds(188, 71, 49, 21);
		panel_2.add(textIDF);
		textIDF.setColumns(10);
		
		
		lista();
	}
	public void lista() {
		DefaultTableModel model = new DefaultTableModel();
		Object[] columns = {"ID_Rol", "Rol", "ID_Funcionalidad", "Funcionalidad"};
		
		model.setColumnIdentifiers(columns);
		
		Object [] fila = new Object[columns.length]; 
		table.setModel(model);
		
		LinkedList<Rol> allRoles = DAORol.findAll();
		
		for (Rol r : allRoles){
			
			r = DAORol.findRolID(r.getIdRol());
			
			LinkedList<Funcionalidad> funciones = r.getFunciones();
			
			for(Funcionalidad f : funciones) {
				
				fila[0] = r.getIdRol();
				fila[1] = r.getNombreRol();
				fila[2] = f.getIdFuncionalidad();
				fila[3] = f.getNombreFuncion();
				
				model.addRow(fila);
			}
		}
	}
}
