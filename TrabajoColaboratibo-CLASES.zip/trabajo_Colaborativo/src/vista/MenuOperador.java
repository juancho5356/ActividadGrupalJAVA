package vista;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class MenuOperador {

	private JFrame frame;
	private JPanel panel;
	private JLabel lblBienvenida_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuOperador window = new MenuOperador();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MenuOperador() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 255, 240));
		frame.setBounds(100, 100, 846, 504);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 0, 0);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		lblBienvenida_1 = new JLabel("Welcome!");
		lblBienvenida_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblBienvenida_1.setForeground(new Color(0, 0, 0));
		lblBienvenida_1.setFont(new Font("Baskerville Old Face", Font.BOLD, 60));
		lblBienvenida_1.setBackground(new Color(0, 206, 209));
		lblBienvenida_1.setBounds(10, 10, 821, 152);
		frame.getContentPane().add(lblBienvenida_1);
		
		JLabel lblNewLabel = new JLabel("Ha iniciado sesion como Operador de seccion");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(554, 10, 277, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnCerrar = new JButton("Cerrar sesion");
		btnCerrar.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnCerrar.setBounds(679, 40, 129, 21);
		frame.getContentPane().add(btnCerrar);
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(0, 0, 831, 467);
		frame.getContentPane().add(lblNewLabel_1);
		
		
	}
}